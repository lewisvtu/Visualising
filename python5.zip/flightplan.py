import matplotlib.pyplot as plt
import numpy as np
import pickler.shelf as shelf
import math
from DBS.dbgrabber import dbsPull
import matplotlib.pyplot as plt
from mpl_toolkits.mplot3d import Axes3D


# SQL = """
#     SELECT
#         DES.GalaxyID,
#         PROG.SnapNum,
#         PROG.Mass,
#         PROG.CentreOfPotential_x,
#         PROG.CentreOfPotential_y,
#         PROG.CentreOfPotential_z,
#         PROG.Redshift
#     FROM
#         RefL0100N1504_Subhalo as PROG with(forceseek),
#         RefL0100N1504_Subhalo as DES,
#         RefL0100N1504_Aperture as AP
#     WHERE
#         DES.SnapNum = 28 and
#         DES.MassType_Star > 1.0e9 and
#         DES.MassType_DM > 5.0e10 and
#         PROG.GalaxyID between DES.GalaxyID and DES.TopLeafID and
#         AP.ApertureSize = 30 and
#         AP.GalaxyID = DES.GalaxyID and
#         AP.Mass_Star > 1.0e9
#     ORDER BY
#         PROG.GalaxyID,
#         PROG.SnapNum
# """

# # Grabs new data from db based on sql. If file name already exists, it loads that data instead

# filename = "FollowProgs2.p"

# raw_dbs = dbsPull(SQL, filename)

# shelf.push(raw_dbs, "followup2")

dbs_data = shelf.pull("followup2")

def gen_surrounding_points(ips, rad, time_space):
    '''
    Generates a set of coords in a square around an important point.
        inputs:
            ips: important points to generate coords about, of the form [[x,y,z,rs],...]
            rad: radius of the points from the important point
            timespace: the redshift offset of the points from the redshift of the important point
        returns:
            points: array of points surrounding ip to be returned, points are of the form [x,y,z,rs]
    '''
    # Takes an galaxy coord [x,y,z,r] we wish to move around and generates 3 points around it
    offsets = [
        np.array([0,rad,0,-time_space]),
        np.array([rad,0,rad,0]),
        np.array([0,-rad,0,time_space])
        ]

    points = []
    for ip in ips:
        for ofs in offsets:
            newpoint = ip + ofs
            points.append(list(newpoint))
    return points


part_snap_galaxies = [list(gal) for gal in dbs_data if gal[1] == 19]
#Grabs all snapshot data for a particular galaxy
part_gal = [list(gal) for gal in dbs_data if gal[0] == 9994243][::-1]
#Cuts the data down to just x,y,z,rs
imp_data = [gal[3:] for gal in part_gal]
interesting_ids = {
    9994243: 19,
   10777540: 18, 
   10351144: 20
}


def nearby(centre_gal, other_gal):
    '''
    takes an important galaxy and another, less important galaxy and returns if it is considered close, within 5mpc
    inputs:
        centre_gal: important galaxy we are centering on
        other_gal: another galaxy that may be considered close
    returns:
        True/ False: if the other galaxy is within/ not within 5mpc
    '''
    if abs(centre_gal[0] - other_gal[0]) < 5.0 and abs(centre_gal[1] - other_gal[1]) < 5.0 and abs(centre_gal[2] - other_gal[2]) < 5.0:
    
        return True
    else:
        return False

def gen_line(sv, ev, frames):
    '''
    input:
        sv, ev : vectors of form [x,y,z,redshift], start and end of line resp.
        frames: no of frames between two coords
    returns:
        xs, ys, zs, sfs: A list of linearly interpolated x, y, z coords and
            scalefactors spaced uniformly in log10(sf)

    '''
    array_sf = find_scalefactors(sv[3], ev[3], frames)
    return np.transpose(np.array([array_sf, np.linspace(sv[0], ev[0], frames), np.linspace(sv[1], ev[1], frames), np.linspace(sv[2], ev[2], frames)]))

gals = np.asarray([list(gal)[3:] for gal in dbs_data if gal[0] in interesting_ids.keys() and gal[1] == interesting_ids[gal[0]]])
gals = gals[np.argsort(gals[:,3])]


nearby_gal_datas = [galaxy[3:] for galaxy in part_snap_galaxies if nearby(gal, galaxy[3:])]


# def find_poly_coefs(xs, ys, zs, rs, deg):
#     x_coefs = np.polyfit(rs, xs, deg)
#     y_coefs = np.polyfit(rs, ys, deg)
#     z_coefs = np.polyfit(rs, zs, deg)
#     return x_coefs[::-1], y_coefs[::-1], z_coefs[::-1]

def find_scalefactors(start_rs, end_rs, frames):
    start_sf = 1/(1.0 + start_rs)
    end_sf = 1/(1.0 + end_rs)
    start_logsf = np.log10(start_sf)
    end_logsf = np.log10(end_sf)
    array_log_sf = np.linspace(start_logsf, end_logsf, frames)
    array_sf = np.power(10, array_log_sf)
    return array_sf[::-1]

# def find_curve_coords(x_coefs, y_coefs, z_coefs, linear_sfs, deg, targ_point):
#     targ_point = targ_point[0]
#     coords = []
#     fnum = 0

#     for sf in linear_sfs:
#         cur_coords = np.zeros(5)
#         cur_coords[0] = fnum
#         cur_coords[1] = sf
#         rs = (1.0/sf) - 1
#         cur_derivs = np.zeros(3)
#         for order in range(0, deg+1):
#             cur_coords[2] = cur_coords[2] + (x_coefs[order] * rs**order)
#             cur_coords[3] = cur_coords[3] + (y_coefs[order] * rs**order)
#             cur_coords[4] = cur_coords[4] + (z_coefs[order] * rs**order)
#         for order in range(1, deg+1):
#             cur_derivs[0] = cur_derivs[0] + (order * x_coefs[order] * rs**(order-1))
#             cur_derivs[1] = cur_derivs[1] + (order * y_coefs[order] * rs**(order-1))
#             cur_derivs[2] = cur_derivs[2] + (order * z_coefs[order] * rs**(order-1))
#         cur_norm = [cur_derivs[2] - cur_derivs[1], cur_derivs[0] - cur_derivs[2], cur_derivs[1] - cur_derivs[0]]
#         lin_indeps = [np.asarray(cur_derivs), np.asarray(cur_norm)]
#         view_dir = np.asarray(targ_point) - cur_coords[2:] 
#         view_dir = view_dir / np.linalg.norm(view_dir)
#         #normalise
#         sec_dir = lin_indeps[0] - np.dot(lin_indeps[0], view_dir) * view_dir
#         sec_dir = sec_dir / np.linalg.norm(sec_dir)

#         #third_dir = lin_indeps[1] - np.dot(lin_indeps[1], view_dir) * view_dir - np.dot(lin_indeps[1], sec_dir) * sec_dir
#         third_dir = np.cross(sec_dir, view_dir)
#         third_dir = third_dir / np.linalg.norm(third_dir)
#         # cur_derivs = cur_derivs / np.linalg.norm(cur_derivs)
#         # cur_norm = cur_norm / np.linalg.norm(cur_norm)
#         # final_base = np.cross(np.asarray(cur_derivs), np.asarray(cur_norm))
#         # final_base = final_base / np.linalg.norm(final_base)
#         comp_set = np.append(cur_coords, [sec_dir, third_dir, view_dir])
#         coords.append(comp_set)
#         fnum += 1
#     return np.asarray(coords)

# def gen_curved_path(key_gals, frames, deg):
#     camera_sfs = find_scalefactors(0.95, 1.03, frames)
#     sur_points = gen_surrounding_points(key_gals, 5.0, 0.025)
#     point_xs = [point[0] for point in sur_points]
#     point_ys = [point[1] for point in sur_points]
#     point_zs = [point[2] for point in sur_points]
#     point_ts = [point[3] for point in sur_points]
#     x_coefs, y_coefs, z_coefs = find_poly_coefs(point_xs, point_ys, point_zs, point_ts, deg)
#     coords = find_curve_coords(x_coefs, y_coefs, z_coefs, camera_sfs, deg, np.asarray(key_gals)[:,:3])
#     return coords

def gen_circular_orbit(key_gal, frames, rad):
    camera_sfs = find_scalefactors(key_gal[3] - 0.5, key_gal[3] + 1, frames)
    angle_int = 2*np.pi / frames
    fs = range(frames)
    xs = [key_gal[0] + rad * np.sin(angle_int * frame) for frame in range(frames)]
    ys = [key_gal[1] + rad * np.cos(angle_int * frame) for frame in range(frames)]
    zs = [key_gal[2] for frame in range(frames)]
    arc_positions = np.transpose(np.asarray([xs,ys,zs]))
    view_dirs = [np.asarray(key_gal[:3]) - arc_position for arc_position in arc_positions]
    view_dirs = np.asarray([view_dir / np.linalg.norm(view_dir) for view_dir in view_dirs])
    ups = np.asarray([np.asarray([0,0,1]) for i in range(frames)])
    final_bases = np.cross(view_dirs, ups)
    return np.transpose(np.array([fs, camera_sfs, xs, ys, zs, final_bases[:,0], final_bases[:,1], final_bases[:,2], ups[:,0], ups[:,1], ups[:,2], view_dirs[:,0], view_dirs[:,1], view_dirs[:,2]]))

def arced_paths(galaxies, radii, frames):
    dir_vects = np.zeros(len(galaxies) - 1)
    for gal_no in range(len(galaxies) - 1):



#coords = gen_curved_path(gals, 100, 3)
#coords = gen_circular_orbit(gal, 100, 5)

# np.savetxt("curvedmanygals.txt", coords, fmt="%i %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f  %.5f", header="RefL0100N1504")

# fns, ts, xs, ys, zs, v1xs, v1ys, v1zs, v2xs, v2ys, v2zs, v3xs, v3ys, v3zs = np.transpose(coords) 


# fig = plt.figure()
# ax = fig.add_subplot(111, projection="3d")

# ax.plot(xs,ys,zs)
# ax.scatter(gals[:,0], gals[:,1], gals[:,2], marker="o", s=200.0, c="#682860")
# for galaxy in nearby_gal_datas:
#     ax.scatter(galaxy[0], galaxy[1], galaxy[2], marker="o", s=50.0)
# ax.quiver(xs,ys,zs, v1xs, v1ys, v1zs, color="#682860", pivot="tail")
# ax.quiver(xs,ys,zs, v2xs, v2ys, v2zs, color="#000000", pivot="tail")
# ax.quiver(xs,ys,zs, v3xs, v3ys, v3zs, color="#FF0000", pivot="tail")
# plt.show()